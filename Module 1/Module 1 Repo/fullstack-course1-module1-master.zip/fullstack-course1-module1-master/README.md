### Module 1

Welcome to Module 1 of the *Ruby on Rails: An Introduction* course by Johns Hopkins University. We are excited to have you in the class and look forward to helping you learn more about how to build web applications with Ruby on Rails.

This is the repository for the PDF files of the slides from Module 1. Each module in the course has a Github repository associated with it. If you have any questions on this module, refer to the FAQ section in the [Wiki] (https://github.com/jhu-ep-coursera/fullstack-course1-module1/wiki) for this repository.

Feel free to explore the resources.

Happy learning !
